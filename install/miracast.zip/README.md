## MagiskMiracast
This module simply adds lines to `system.prop` file to enable Miracast and Thethering. There are additinal lines for ADB notify disable and HDMI settings.

After installing and rebooting, go to Settings > Display > Cast > Click the 3 dots > Enable Wireless Display > Done.

Now you can mirror your phone's screen to any Miracast supported device, such as TVs and Windows 10 PCs.
