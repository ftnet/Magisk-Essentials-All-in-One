## ViPER4Android
Download the latest APK (2.5.0.5) [here](https://www.androidfilehost.com/?fid=312978532265364193)  
[Official V4A thread](http://forum.xda-developers.com/showthread.php?t=2191223)  
This is a port of ViPER4Android to Magisk
